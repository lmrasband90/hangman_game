from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
# from flask_app.__init__ import app
from flask_app import app
import random





# def display_word_w_blanks():
#     letters_so_far = 'cement'
#     displayed_word = '_ '
#     # get length of letters_so_far
#     x = len(letters_so_far)
#     # concatonate displayed_word to itself the x times 
#     displayed_word = displayed_word * x
#     print(displayed_word)






