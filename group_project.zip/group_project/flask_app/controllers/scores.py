from flask_app import app
from flask import redirect, render_template, request, session, flash
from flask_app.models.score import Score
from flask_app.models.user import User
# from flask_app.models.word import Word
