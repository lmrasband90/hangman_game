from flask_app import app
from flask import Flask, redirect, render_template, request, session, flash
from flask_app.models.user import User
from flask_app.models.score import Score
import random



words = ['continue', 'bottle', 'guitar', 'chair', 'cement', 'stable', 'cabinet', 'telephone']

print(words)
print('i love my doggie')

def choose_word():
    chosen_word = random.choice(words)
    print(chosen_word)
    return chosen_word



# function for filling in the letters if they get one right (and keeping them there)
# only run if the letter is in the word
# def replace_blanks_w_letters():
    # loop through chosen_word
    # every time the letter youre on = guessed_letter, 
    # change the item in the string at the index your're on to the letter


# def replace_blanks_w_letters():
#     chosen_word = session['chosen_word']
#     guessed_letter = session['guessed_letter']
#     displayed_word = session['displayed_word']
#     for i in chosen_word:
#         if i == guessed_letter:
#             displayed_word[i] = guessed_letter






@app.route('/start-game')
def start_game():
    session['chosen_word'] = choose_word()
    session['letters_so_far'] = []
    session['guessed_letter'] = ''
    session['displayed_word'] = '_'
    x = len(session['chosen_word'])
    session['displayed_word'] = session['displayed_word'] * x
    print(session['displayed_word'])
    return redirect('/guess-letter')



def replace_blanks_w_letters(chosen_word, guessed_letter):
    print('testing testing')
    print('session',session)
    # chosen_word = session['chosen_word']
    # guessed_letter = session['guessed_letter']
    displayed_word = session['displayed_word']

    # occurences = chosen_word.count(guessed_letter)
    # chosen_word = list(chosen_word)
    # displayed_word = list(displayed_word)

    if guessed_letter in session:
        for i in range(len(displayed_word)):
            print('Index', i)
            if chosen_word[i] == guessed_letter:
                displayed_word[i] = guessed_letter
                print('index', i)
        # print('occurences', occurences)
        return 'displayed_word', displayed_word








@app.route('/guess-letter', methods=['GET', 'POST'])
def handle_guess():

    message = None

    if request.method == "POST":
        displayed_word = session['displayed_word']
        if 'guessed_letter' in request.form:
            guessed_letter = request.form['guessed_letter']
            print(guessed_letter)


# now testing to see if there are previous guesses
            if 'letters_so_far' in session:
                letters_so_far = session['letters_so_far']
                print(letters_so_far)
                session['letters_so_far'].append(guessed_letter)
                session.modified = True
# if letters_so_far isn't in session, it's your first guess
            else:
                session['letters_so_far'] = [guessed_letter]

# this is checking if the letter is in the word
            chosen_word = session['chosen_word']
            if guessed_letter in session['chosen_word']:
                replace_blanks_w_letters(chosen_word, guessed_letter)
                message = f'good job, {guessed_letter} is in  {chosen_word}.'
                print(message)
            else:
                message = f'nope, sorry, {guessed_letter}  is not in  {chosen_word}.'
                print(message)
            print(session['letters_so_far'])


    return render_template('dashboard.html', message = message)














# @app.route('/guess-letter', methods=['POST'])
# def handle_guess():
#     chosen_word = choose_word()
#     print(chosen_word)
#     data = {
#         'guessed_letter': request.form['guessed_letter']
#     }
#     session['users_guess'] = users_guess
#     guessed_letter = request.form('guessed_letter') 
#     print(data)
    # if users_guess in chosen_word:
    #     print('good job, that letter is in the word')
    # else:
    #     print('nope, sorry, that letter is not in the word')
#     return redirect('/dashboard')




# ------------------this one works--------
# @app.route('/guess-letter', methods=['POST'])
# def handle_guess():
#     data = {
#         'guessed_letter': request.form['guessed_letter']
#     }
#     print(data)
#     return redirect('/dashboard')





